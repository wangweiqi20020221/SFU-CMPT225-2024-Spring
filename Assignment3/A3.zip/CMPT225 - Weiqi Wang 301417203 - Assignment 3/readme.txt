Weiqi Wang, wwa97, 301417203
Design Documentation: IPQ.h
Testing Regimen: test.cpp